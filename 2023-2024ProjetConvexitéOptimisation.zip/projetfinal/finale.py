# -*- coding: utf-8 -*-
"""
Created on Sat Jul 20 17:30:05 2024

@author: PC
"""

import tkinter as tk
from tkinter import filedialog, ttk
import pandas as pd
import re
from pulp import LpProblem, LpVariable, lpSum, LpMinimize
import pulp
from PIL import Image, ImageTk

def solve_op(base1, base2, base3, hospitals, banks, blood_types):
    prob = LpProblem("Optimisation_Banques_Sang", LpMinimize)
    Q = pulp.LpVariable.dicts("Q", ((i, j, k) for i in banks for j in hospitals for k in blood_types), lowBound=0, cat='Continuous')

    demand = {(row['Hospital_ID'], bt): row[bt] for index, row in base1.iterrows() for bt in blood_types}
    capacity = {(row['Bank_ID'], bt): row[f'Capacity_{bt}'] for index, row in base2.iterrows() for bt in blood_types}
    collect_cost = {(row['Bank_ID'], bt): row[f'Collect_Cost_{bt}'] for index, row in base2.iterrows() for bt in blood_types}
    delivery_cost = {(row['Bank_ID'], row['Hospital_ID'], bt): row[f'Delivery_Cost_{bt}'] for index, row in base3.iterrows() for bt in blood_types}

    prob += lpSum(Q[i, j, k] * collect_cost[i, k] for i in banks for j in hospitals for k in blood_types) + \
            lpSum(Q[i, j, k] * delivery_cost[i, j, k] for i in banks for j in hospitals for k in blood_types)

    for j in hospitals:
        for k in blood_types:
            prob += lpSum(Q[i, j, k] for i in banks) == demand[j, k]
    for i in banks:
        for k in blood_types:
            prob += lpSum(Q[i, j, k] for j in hospitals) <= capacity[i, k]

    prob.solve()

    results = {'Bank_ID': [], 'Hospital_ID': [], 'Blood_Type': [], 'Quantity': []}
    total_cost = 0
    
    for var in prob.variables():
        name_parts = re.findall(r"'([^']*)'", var.name)
        if len(name_parts) == 3:
            results['Bank_ID'].append(name_parts[0])
            results['Hospital_ID'].append(name_parts[1])
            results['Blood_Type'].append(name_parts[2])
            results['Quantity'].append(var.varValue)
            total_cost += var.varValue * collect_cost[name_parts[0], name_parts[2]] + \
                          var.varValue * delivery_cost[name_parts[0], name_parts[1], name_parts[2]]
    results_df = pd.DataFrame(results)
    return results_df, total_cost

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Application Multi-pages")
        self.geometry("900x900")
        self.frames = {}
        self.dataframes = {}

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(expand=True, fill='both')

        for F in (HomePage, CSVPage, DisplayPage):
            page_name = F.__name__
            frame = F(parent=self.notebook, controller=self)
            self.frames[page_name] = frame
            self.notebook.add(frame, text=page_name)

        self.show_frame("HomePage")

    def show_frame(self, page_name):
        frame = self.frames[page_name]
        self.notebook.select(frame)

    def show_dataframe(self, df_name):
        frame = self.frames['DisplayPage']
        df = self.dataframes[df_name]
        is_result = df_name == "resultat"
        total_cost = self.dataframes.get('total_cost', 0) if is_result else 0
        frame.update_treeview(df, total_cost, is_result, df_name)
        self.show_frame('DisplayPage')

    def check_all_files_loaded(self):
        return all(key in self.dataframes for key in ['base hôpitaux', 'base banque de sang', 'base des coûts'])

class HomePage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        self.canvas = tk.Canvas(self, width=900, height=900, highlightthickness=0)
        self.canvas.pack(fill='both', expand=True)
        self.set_background('photo2.jpeg')

        label = tk.Label(self.canvas, text="Page d'accueil", font=('Arial', 24, 'bold'), bg='black', fg='white')
        label.pack(pady=20)

        button = tk.Button(self.canvas, text="Aller à la page de sélection de fichier CSV",
                           command=lambda: controller.show_frame("CSVPage"), font=('Arial', 20, 'bold'), width=40, height=2, bg="#87CEEB", fg="black", borderwidth=0)
        button.pack(pady=10)

        self.buttons_frame = tk.Frame(self.canvas, bg='', borderwidth=0)
        self.buttons_frame.pack(pady=20, padx=20, fill='x')

        self.analyze_button = tk.Button(self.canvas, text="Analyser", command=self.analyze_data, font=('Arial', 20, 'bold'), width=30, height=2, borderwidth=0, bg="#4682B4", fg="white")
        self.analyze_button.pack(pady=20)

        self.update_buttons()

    def set_background(self, image_path):
        self.original_image = Image.open(image_path)
        self.bg_image = ImageTk.PhotoImage(self.original_image)
        self.canvas.create_image(0, 0, image=self.bg_image, anchor='nw')
        self.canvas.bind("<Configure>", self.resize_image)

    def resize_image(self, event):
        new_width = event.width
        new_height = event.height
        resized_image = self.original_image.resize((new_width, new_height), Image.LANCZOS)
        self.bg_image = ImageTk.PhotoImage(resized_image)
        self.canvas.create_image(0, 0, image=self.bg_image, anchor='nw')

    def update_buttons(self):
        for widget in self.buttons_frame.winfo_children():
            widget.destroy()

        for df_name in self.controller.dataframes:
            button = tk.Button(self.buttons_frame, text=f"Voir la {df_name}",
                               command=lambda name=df_name: self.controller.show_dataframe(name),
                               font=('Arial', 20, 'bold'), width=20, height=2, borderwidth=0, bg="#87CEEB", fg="black")
            button.pack(pady=10, padx=10, fill='x')

        if self.controller.check_all_files_loaded():
            self.analyze_button.pack(pady=20)
        else:
            self.analyze_button.pack_forget()

    def analyze_data(self):
        base1 = self.controller.dataframes['base hôpitaux']
        base2 = self.controller.dataframes['base banque de sang']
        base3 = self.controller.dataframes['base des coûts']
        hospitals = base1['Hospital_ID'].tolist()
        banks = base2['Bank_ID'].tolist()
        blood_types = ['A1', 'A2', 'B1', 'B2', 'AB1', 'AB2', 'O1', 'O2']
        data, cost = solve_op(base1, base2, base3, hospitals, banks, blood_types)
        self.controller.dataframes["base des resultats"] = data
        self.update_buttons()
        self.controller.show_frame("HomePage")

class CSVPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        self.canvas = tk.Canvas(self, width=900, height=900)
        self.canvas.pack(fill='both', expand=True)
        self.set_background('photo2.jpeg')

        label = tk.Label(self.canvas, text="Veuillez sélectionner votre fichier", font=('Arial', 24, 'bold'), bg='black', fg="white")
        label.pack(pady=20)

        open_button1 = tk.Button(self.canvas, text="Ouvrir le fichier des hôpitaux", command=lambda: self.open_file('base hôpitaux'), font=('Arial', 20, 'bold'), width=30, height=2, bg="#4682B4", fg="white", borderwidth=0)
        open_button1.pack(pady=20)

        open_button2 = tk.Button(self.canvas, text="Ouvrir le fichier des banques de sang", command=lambda: self.open_file('base banque de sang'), font=('Arial', 20, 'bold'), width=30, height=2, bg="#4682B4", fg="white", borderwidth=0)
        open_button2.pack(pady=20)

        open_button3 = tk.Button(self.canvas, text="Ouvrir le fichier des coûts de livraison", command=lambda: self.open_file('base des coûts'), font=('Arial', 20, 'bold'), width=30, height=2, bg="#4682B4", fg="white", borderwidth=0)
        open_button3.pack(pady=20)

        back_button = tk.Button(self.canvas, text="Retour à l'accueil",
                                command=lambda: controller.show_frame("HomePage"), font=('Arial', 20, 'bold'), width=20, height=2, fg='darkblue', bg='lightgrey')
        back_button.pack(pady=20)

    def set_background(self, image_path):
        self.original_image = Image.open(image_path)
        self.bg_image = ImageTk.PhotoImage(self.original_image)
        self.canvas.create_image(0, 0, image=self.bg_image, anchor='nw')
        self.canvas.bind("<Configure>", self.resize_image)

    def resize_image(self, event):
        new_width = event.width
        new_height = event.height
        resized_image = self.original_image.resize((new_width, new_height), Image.LANCZOS)
        self.bg_image = ImageTk.PhotoImage(resized_image)
        self.canvas.create_image(0, 0, image=self.bg_image, anchor='nw')

    def open_file(self, file_type):
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if file_path:
            df = pd.read_csv(file_path)
            self.controller.dataframes[file_type] = df
            self.controller.frames['HomePage'].update_buttons()
            self.controller.show_frame("HomePage")

class DisplayPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.tree = None
        self.total_cost_label = None
        self.canvas = tk.Canvas(self, width=900, height=900)
        self.canvas.pack(fill='both', expand=True)
        self.set_background('photo1.jpeg')

        self.label = tk.Label(self.canvas, text="Affichage des données", font=('Arial', 24, 'bold'), bg='white')
        self.label.pack(pady=20)

        self.tree_frame = tk.Frame(self.canvas)
        self.tree_frame.pack(expand=True, fill='both')

        self.tree_scroll_y = tk.Scrollbar(self.tree_frame, orient='vertical')
        self.tree_scroll_x = tk.Scrollbar(self.tree_frame, orient='horizontal')

        back_button = tk.Button(self.canvas, text="Retour à l'accueil",
                                command=lambda: controller.show_frame("HomePage"), font=('Arial', 20, 'bold'), width=20, height=2, fg='darkblue', bg='lightgrey')
        back_button.pack(pady=20, padx=0)

    def set_background(self, image_path):
        self.original_image = Image.open(image_path)
        self.bg_image = ImageTk.PhotoImage(self.original_image)
        self.canvas.create_image(0, 0, image=self.bg_image, anchor='nw')
        self.canvas.bind("<Configure>", self.resize_image)

    def resize_image(self, event):
        new_width = event.width
        new_height = event.height
        resized_image = self.original_image.resize((new_width, new_height), Image.LANCZOS)
        self.bg_image = ImageTk.PhotoImage(resized_image)
        self.canvas.create_image(0, 0, image=self.bg_image, anchor='nw')

    def update_treeview(self, df, total_cost, is_result, df_name):
        if self.tree is not None:
            self.tree.destroy()

        self.tree = ttk.Treeview(self.tree_frame, yscrollcommand=self.tree_scroll_y.set, xscrollcommand=self.tree_scroll_x.set, style='Treeview')
        self.tree.pack(expand=True, fill='both')

        self.tree_scroll_y.config(command=self.tree.yview)
        self.tree_scroll_y.pack(side='right', fill='y')
        self.tree_scroll_x.config(command=self.tree.xview)
        self.tree_scroll_x.pack(side='bottom', fill='x')

        self.tree["column"] = list(df.columns)
        self.tree["show"] = "headings"

        style = ttk.Style()
        style.configure('Treeview', rowheight=30, font=('Arial', 12))
        style.configure('Treeview.Heading', font=('Arial', 14, 'bold'))

        for column in self.tree["columns"]:
            self.tree.heading(column, text=column)
            self.tree.column(column, anchor='center')

        colors = ['#f0f8ff', '#e6e6fa', '#fff0f5', '#e0ffff', '#f5f5dc', '#f0fff0', '#e0f8e0', '#f5f5f5']
        bank_color = {bank: colors[i % len(colors)] for i, bank in enumerate(df['Bank_ID'].unique())}

        for index, row in df.iterrows():
            bank = row['Bank_ID']
            self.tree.insert("", "end", values=list(row), tags=(bank,))
            self.tree.tag_configure(bank, background=bank_color[bank])

        if df_name == 'base hôpitaux':
            self.label.config(text="Données des hôpitaux")
        elif df_name == 'base banque de sang':
            self.label.config(text="Données des banques de sang")
        elif df_name == 'base des coûts':
            self.label.config(text="Données des coûts")
        else:
            self.label.config(text="Affichage des données")

        if is_result:
            if self.total_cost_label is None:
                self.total_cost_label = tk.Label(self.canvas, text=f"Coût total: {total_cost:.2f}", font=('Arial', 20, 'bold'), bg='white', fg='#FF6347')
                self.total_cost_label.pack(padx=20)
            else:
                self.total_cost_label.config(text=f"Coût total: {total_cost:.2f}")
        elif self.total_cost_label:
            self.total_cost_label.pack_forget()

if __name__ == "__main__":
    app = App()
    app.mainloop()
